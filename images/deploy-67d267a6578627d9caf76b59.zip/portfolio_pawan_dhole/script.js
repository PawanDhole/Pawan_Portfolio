document.addEventListener('DOMContentLoaded', () => {
    console.log('Portfolio loaded');
    // Add your JavaScript code here
});
